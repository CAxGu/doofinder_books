Instrucciones:
Ejecutar fichero launcher.bat para crear y arrancar tu contenedor Docker